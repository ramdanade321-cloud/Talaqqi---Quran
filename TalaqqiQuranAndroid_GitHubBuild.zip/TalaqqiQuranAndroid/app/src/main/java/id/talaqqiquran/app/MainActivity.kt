package id.talaqqiquran.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.media.MediaPlayer
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Surah(val number: Int, val name: String, val english: String, val ayahs: Int)
data class Ayah(val numberInSurah: Int, val text: String, val audio: String)

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var mediaPlayer: MediaPlayer? = null
    private val surahs = mutableListOf<Surah>()
    private val ayahs = mutableListOf<Ayah>()
    private var surahIndex = 0
    private var ayahIndex = 0
    private var repeatTarget = 3
    private var repeatDone = 0
    private var autoRepeat = false
    private var chunkMode = false
    private var isPlaying = false

    private lateinit var status: TextView
    private lateinit var surahSpinner: Spinner
    private lateinit var qariSpinner: Spinner
    private lateinit var ayahText: TextView
    private lateinit var translationLabel: TextView
    private lateinit var ayahProgress: TextView
    private lateinit var repeatSpinner: Spinner
    private lateinit var repeatCheck: CheckBox
    private lateinit var chunkCheck: CheckBox
    private lateinit var playButton: Button
    private lateinit var prevButton: Button
    private lateinit var nextButton: Button
    private lateinit var loadButton: Button

    private val qaris = listOf(
        "Mishary Alafasy" to "ar.alafasy",
        "Abdurrahman As-Sudais" to "ar.abdurrahmaansudais",
        "Mahmoud Khalil Al-Husary" to "ar.husary"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadSurahList()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(246, 249, 246))
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(outer)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "تَلَاقِّي الْقُرْآن\nTALAQQI QUR'AN"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(12), dp(20), dp(12), dp(20))
            setBackgroundColor(Color.rgb(16, 92, 66))
        }
        outer.addView(header, matchWrap())

        val intro = TextView(this).apply {
            text = "Dengarkan • Tirukan • Ulangi • Sambung Hafalan"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 85, 62))
            setPadding(0, dp(12), 0, dp(12))
        }
        outer.addView(intro, matchWrap())

        outer.addView(label("Pilih surah"))
        surahSpinner = Spinner(this)
        outer.addView(surahSpinner, matchWrap())

        outer.addView(label("Pilih qari"))
        qariSpinner = Spinner(this)
        qariSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, qaris.map { it.first })
        outer.addView(qariSpinner, matchWrap())

        loadButton = Button(this).apply {
            text = "Muat Surah"
            setOnClickListener { loadSelectedSurah() }
        }
        outer.addView(loadButton, matchWrap())

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.topMargin = dp(14)
        outer.addView(card, params)

        ayahProgress = TextView(this).apply {
            text = "Ayat —"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(16, 92, 66))
            setTypeface(null, Typeface.BOLD)
        }
        card.addView(ayahProgress, matchWrap())

        ayahText = TextView(this).apply {
            text = "Memuat daftar surah..."
            textSize = 29f
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_RTL
            setTextColor(Color.rgb(30, 35, 30))
            setPadding(0, dp(20), 0, dp(20))
            setLineSpacing(dp(8).toFloat(), 1.1f)
        }
        card.addView(ayahText, matchWrap())

        translationLabel = TextView(this).apply {
            text = "Teks Arab ditampilkan dari sumber Al-Qur'an daring."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        card.addView(translationLabel, matchWrap())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        prevButton = Button(this).apply {
            text = "⏮ Ayat"
            setOnClickListener { stopAudio(); moveAyah(-1) }
        }
        playButton = Button(this).apply {
            text = "▶ Putar"
            setOnClickListener { togglePlayback() }
        }
        nextButton = Button(this).apply {
            text = "Ayat ⏭"
            setOnClickListener { stopAudio(); moveAyah(1) }
        }
        controls.addView(prevButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(playButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(nextButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(controls, matchWrap())

        outer.addView(label("Jumlah pengulangan"))
        repeatSpinner = Spinner(this)
        repeatSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1 kali", "3 kali", "5 kali", "10 kali", "Tanpa batas"))
        repeatSpinner.setSelection(1)
        repeatSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                repeatTarget = when (position) { 0 -> 1; 1 -> 3; 2 -> 5; 3 -> 10; else -> Int.MAX_VALUE }
            }
        }
        outer.addView(repeatSpinner, matchWrap())

        repeatCheck = CheckBox(this).apply {
            text = "Ulangi otomatis ayat yang sama"
            isChecked = true
        }
        outer.addView(repeatCheck, matchWrap())

        chunkCheck = CheckBox(this).apply {
            text = "Mode latihan potongan ayat (teks bertahap)"
            setOnCheckedChangeListener { _, checked ->
                chunkMode = checked
                renderAyah()
            }
        }
        outer.addView(chunkCheck, matchWrap())

        status = TextView(this).apply {
            text = "Menyiapkan aplikasi..."
            textSize = 13f
            setTextColor(Color.rgb(80, 80, 80))
            setPadding(0, dp(10), 0, 0)
        }
        outer.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "Catatan: latihan potongan menampilkan teks secara bertahap, sedangkan audio tetap membaca satu ayat penuh. Koneksi internet diperlukan. Untuk ketepatan tajwid dan makhraj, tetap setorkan bacaan kepada guru."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(14), 0, 0)
        }
        outer.addView(note, matchWrap())
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 15f
        setTextColor(Color.rgb(35, 65, 48))
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun request(url: String, callback: (String?) -> Unit) {
        worker.execute {
            var result: String? = null
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 12000
                conn.readTimeout = 18000
                conn.setRequestProperty("User-Agent", "TalaqqiQuranAndroid/1.0")
                result = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { callback(result) }
        }
    }

    private fun loadSurahList() {
        status.text = "Mengambil daftar surah dari internet..."
        request("https://api.alquran.cloud/v1/surah") { body ->
            if (body == null) {
                status.text = "Gagal mengambil daftar surah. Periksa internet lalu coba lagi."
                ayahText.text = "Koneksi internet diperlukan"
                return@request
            }
            try {
                val data = JSONObject(body).getJSONArray("data")
                surahs.clear()
                for (i in 0 until data.length()) {
                    val s = data.getJSONObject(i)
                    surahs.add(Surah(s.getInt("number"), s.getString("name"), s.getString("englishName"), s.getInt("numberOfAyahs")))
                }
                surahSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                    surahs.map { "${it.number}. ${it.english} — ${it.name}" })
                status.text = "Daftar 114 surah siap. Pilih surah, qari, lalu tekan Muat Surah."
                loadSelectedSurah()
            } catch (_: Exception) {
                status.text = "Data surah tidak dapat dibaca."
            }
        }
    }

    private fun loadSelectedSurah() {
        if (surahs.isEmpty()) return
        stopAudio()
        surahIndex = surahSpinner.selectedItemPosition.coerceIn(0, surahs.lastIndex)
        ayahIndex = 0
        val surah = surahs[surahIndex]
        val edition = qaris[qariSpinner.selectedItemPosition.coerceIn(0, qaris.lastIndex)].second
        status.text = "Memuat ${surah.english}..."
        // The selected audio edition supplies both the verse text and its audio URLs.
        request("https://api.alquran.cloud/v1/surah/${surah.number}/$edition") { body ->
            if (body == null) {
                status.text = "Gagal memuat surah. Periksa koneksi atau coba qari lain."
                return@request
            }
            try {
                val arr = JSONObject(body).getJSONObject("data").getJSONArray("ayahs")
                ayahs.clear()
                for (i in 0 until arr.length()) {
                    val a = arr.getJSONObject(i)
                    ayahs.add(Ayah(a.getInt("numberInSurah"), a.optString("text", ""), a.optString("audio", "")))
                }
                renderAyah()
                status.text = "${surah.english} siap • ${ayahs.size} ayat • Qari: ${qaris[qariSpinner.selectedItemPosition].first}"
            } catch (_: Exception) {
                status.text = "Data surah tidak dapat dibaca untuk qari ini."
            }
        }
    }

    private fun renderAyah() {
        if (ayahs.isEmpty()) return
        val a = ayahs[ayahIndex.coerceIn(0, ayahs.lastIndex)]
        ayahProgress.text = "${surahs.getOrNull(surahIndex)?.english ?: "Surah"} • Ayat ${a.numberInSurah} / ${ayahs.size}"
        if (chunkMode) {
            val words = a.text.trim().split(Regex("\\s+"))
            val visibleCount = ((words.size + 1) / 2).coerceAtLeast(1)
            ayahText.text = words.take(visibleCount).joinToString(" ") + "\n\n… lanjutkan hafalan"
            translationLabel.text = "Potongan awal ditampilkan. Gunakan tombol Putar untuk mendengar ayat penuh."
        } else {
            ayahText.text = a.text
            translationLabel.text = "Baca dan tirukan pelafalan qari."
        }
    }

    private fun togglePlayback() {
        if (ayahs.isEmpty()) {
            status.text = "Tunggu hingga surah selesai dimuat."
            return
        }
        if (isPlaying) {
            mediaPlayer?.pause()
            isPlaying = false
            playButton.text = "▶ Lanjut"
            status.text = "Audio dijeda."
            return
        }
        if (mediaPlayer != null) {
            try {
                mediaPlayer?.start()
                isPlaying = true
                playButton.text = "⏸ Jeda"
                return
            } catch (_: Exception) { mediaPlayer = null }
        }
        playCurrentAyah()
    }

    private fun playCurrentAyah() {
        if (ayahs.isEmpty()) return
        val url = ayahs[ayahIndex].audio
        if (url.isBlank()) {
            status.text = "Audio untuk ayat ini tidak tersedia pada qari yang dipilih."
            return
        }
        stopAudio()
        status.text = "Memutar ayat ${ayahs[ayahIndex].numberInSurah}..."
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener {
                    it.start()
                    isPlaying = true
                    playButton.text = "⏸ Jeda"
                    status.text = "Sedang memutar ayat ${ayahs[ayahIndex].numberInSurah}."
                }
                setOnCompletionListener {
                    isPlaying = false
                    playButton.text = "▶ Putar"
                    repeatDone++
                    if (repeatCheck.isChecked && repeatDone < repeatTarget) {
                        playCurrentAyah()
                    } else {
                        repeatDone = 0
                        status.text = "Selesai. Anda bisa mengulang atau lanjut ke ayat berikutnya."
                    }
                }
                setOnErrorListener { _, _, _ ->
                    isPlaying = false
                    playButton.text = "▶ Putar"
                    status.text = "Audio gagal diputar. Periksa koneksi internet."
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            status.text = "Tidak bisa memulai audio. Coba lagi."
        }
    }

    private fun moveAyah(delta: Int) {
        if (ayahs.isEmpty()) return
        ayahIndex = (ayahIndex + delta).coerceIn(0, ayahs.lastIndex)
        repeatDone = 0
        renderAyah()
        status.text = "Ayat ${ayahs[ayahIndex].numberInSurah} dipilih."
    }

    private fun stopAudio() {
        try {
            mediaPlayer?.setOnCompletionListener(null)
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) { }
        mediaPlayer = null
        isPlaying = false
        if (::playButton.isInitialized) playButton.text = "▶ Putar"
    }

    override fun onDestroy() {
        stopAudio()
        worker.shutdownNow()
        super.onDestroy()
    }
}
